/* populate expensetypes table */
INSERT INTO expensetypes (etypeName)
VALUES ('Gasoline');
INSERT INTO expensetypes (etypeName)
VALUES ('Postage/Courier');
INSERT INTO expensetypes (etypeName)
VALUES ('Transportation');
INSERT INTO expensetypes (etypeName)
VALUES ('Food');
INSERT INTO expensetypes (etypeName)
VALUES ('Filing Fee');
INSERT INTO expensetypes (etypeName)
VALUES ('TSN');
INSERT INTO expensetypes (etypeName)
VALUES ('Facilitation');
INSERT INTO expensetypes (etypeName)
VALUES ('Others');