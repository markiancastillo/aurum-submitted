insert into servicetypes (stypeName) 
values ('General Counseling and Retainer');

insert into servicetypes (stypeName) 
values ('Corporate');

insert into servicetypes (stypeName) 
values ('Intellectual Property');

insert into servicetypes (stypeName) 
values ('Immigration');

insert into servicetypes (stypeName) 
values ('Labor');

insert into servicetypes (stypeName) 
values ('Real Estate and Property Management');

insert into servicetypes (stypeName) 
values ('Litigation and Dispute Resolution');

insert into servicetypes (stypeName) 
values ('Telecommunications');

insert into servicetypes (stypeName) 
values ('Tax');