/* populate contact types table */
INSERT INTO contacttypes (ctypeName) 
VALUES ('Main'); 
INSERT INTO contacttypes (ctypeName) 
VALUES ('Mobile');
INSERT INTO contacttypes (ctypeName) 
VALUES ('Home');
INSERT INTO contacttypes (ctypeName) 
VALUES ('Office');
INSERT INTO contacttypes (ctypeName) 
VALUES ('Fax');