/* populate departments table */
INSERT INTO departments(departmentName)
VALUES ('Administrative');
INSERT INTO departments(departmentName)
VALUES ('Counsel');
INSERT INTO departments(departmentName)
VALUES ('Associate');
INSERT INTO departments(departmentName)
VALUES ('Human Resource and Finance');
INSERT INTO departments(departmentName)
VALUES ('Operations');