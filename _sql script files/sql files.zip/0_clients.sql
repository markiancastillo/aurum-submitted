/* inert data into clients table */
/* name: kevin smith */
INSERT INTO clients (clientFN, clientMN, clientLN, clientEmail)
VALUES ('33zmQsVjuhbFRvCFHwHWWw==', 'n6RHVJVfFATh9PsZjyzW+w==', 'aFs5CbLMAGr40lBegi32tQ==', '8zW3Tpe0jkPslUJfavxaXGz23cXSKD+ERrrNzhFM/Sc=');

/* name: amanda barnes */
INSERT INTO clients (clientFN, clientMN, clientLN, clientEmail)
VALUES ('g2roBoTF0EJMs9ttCxV67w==', 'n6RHVJVfFATh9PsZjyzW+w==', 'oUy4jJwE1LLYsFQu/LNMqA==', 'SV9QK8tcs6QlMHIjkeEthoEoU45VL4XyC4L/qKJgGeM=');