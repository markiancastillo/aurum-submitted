/* populate civil status table */
INSERT INTO civilstatuses (cstatusName, cstatusDescription)
VALUES ('Single', 'Single');
INSERT INTO civilstatuses (cstatusName, cstatusDescription)
VALUES ('Married', 'Married');
INSERT INTO civilstatuses (cstatusName, cstatusDescription)
VALUES ('Widowed', 'Widowed');
INSERT INTO civilstatuses (cstatusName, cstatusDescription)
VALUES ('Divorced', 'Divorced');
INSERT INTO civilstatuses (cstatusName, cstatusDescription)
VALUES ('Separated', 'Separated');
INSERT INTO civilstatuses (cstatusName, cstatusDescription)
VALUES ('Registered Partnership', 'Registered Partnership');